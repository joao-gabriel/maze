$(document).ready(function(){
  
  $('.sala').click(function(){
    var numSala = $(this).children(':hidden').val();
      
  });
  
});